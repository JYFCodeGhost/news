//
//  JYFbaseTableViewCell3.h
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYFBaseModel;
@interface JYFbaseTableViewCell3 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *title3Label;
@property (weak, nonatomic) IBOutlet UIImageView *image1VIew;
@property (weak, nonatomic) IBOutlet UIImageView *iamge2View;

@property (weak, nonatomic) IBOutlet UIImageView *image3View;
@property (weak, nonatomic) IBOutlet UILabel *category3Label;
@property (weak, nonatomic) IBOutlet UILabel *comment3Label;

@property (weak, nonatomic) IBOutlet UILabel *time3Label;
@property (weak, nonatomic) IBOutlet UIImageView *x3ImageView;

/**model*/
@property(nonatomic, strong)JYFBaseModel *model3;

@end
