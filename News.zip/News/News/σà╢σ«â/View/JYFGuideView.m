//
//  JYFGuideView.m
//  News
//
//  Created by 千锋 on 16/6/7.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFGuideView.h"

@implementation JYFGuideView

+(instancetype)guideView {


    return [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil] lastObject];
}

- (IBAction)OKAction:(UIButton *)sender {
    [self removeFromSuperview];
}
+(void)showGuideView {
    NSString *key = @"CFBundleShortVersionString";
    //获取当前版本号
    NSString *currentVersion = [NSBundle mainBundle].infoDictionary[key];
    //沙盒路径下的版本号
    NSString *shaBox= [[NSUserDefaults standardUserDefaults] stringForKey:key];
    //如果不相同就加载引导页
    if (![currentVersion isEqualToString:shaBox]) {
        JYFGuideView *guideView=[JYFGuideView guideView];
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        guideView.frame=window.bounds;
        [window addSubview:guideView];
        //将版本信息存进沙盒
        [[NSUserDefaults standardUserDefaults] setValue:currentVersion forKey:key];
        //马山存储
        [[NSUserDefaults standardUserDefaults] synchronize];
    }


}
@end
