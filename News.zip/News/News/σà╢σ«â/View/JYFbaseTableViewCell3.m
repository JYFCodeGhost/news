//
//  JYFbaseTableViewCell3.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFbaseTableViewCell3.h"
#import "JYFBaseModel.h"
@implementation JYFbaseTableViewCell3

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setModel3:(JYFBaseModel *)model3 {

    if (model3.CoverImgs.count==3) {
        _model3=model3;
               [self.image1VIew sd_setImageWithURL:[NSURL URLWithString:_model3.CoverImgs[0]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
        
        [self.image3View sd_setImageWithURL:[NSURL URLWithString:_model3.CoverImgs[1]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
        
        [self.iamge2View sd_setImageWithURL:[NSURL URLWithString:_model3.CoverImgs[2]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
        self.title3Label.text=_model3.Title;
        self.category3Label.text=_model3.FromName;
        
        self.comment3Label.text=[NSString stringWithFormat:@"%ld",_model3.CommentCount];
        self.time3Label.text=_model3.showTimeStr;
        
    }


}

@end
