//
//  NSDate+WTExtension.m
//  百思不得姐
//
//  Created by GRIM on 16/5/22.
//  Copyright © 2016年 董文涛. All rights reserved.
//

#import "NSDate+WTExtension.h"

@implementation NSDate (WTExtension)

- (NSDateComponents *)deltaFrom:(NSDate *)from{
    
    //日历
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSCalendarUnit unit = NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond;
    
    return [calendar components:unit fromDate:from toDate:self options:0];
    
}

//是否是今年
- (BOOL)isThisYear{
    
    //日历
    NSCalendar *calender = [NSCalendar currentCalendar];
    
    NSInteger nowYear = [calender component:NSCalendarUnitYear fromDate:[NSDate date]];
     
     NSInteger selfYear = [calender component:NSCalendarUnitYear fromDate:self];
    
    return nowYear == selfYear;
    
}

//是否是今天
- (BOOL)isToday{
    
//    //第一种做法
//    //日历
//    NSCalendar *calender = [NSCalendar currentCalendar];
//    
//    NSCalendarUnit unit = NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay;
//    
//    NSDateComponents *today = [calender components:unit fromDate:[NSDate date]];
//    
//    NSDateComponents *selfDay = [calender components:unit fromDate:self];
//    
//    return today.year == selfDay.year
//    &&today.month == selfDay.month
//    &&today.day == selfDay.day;
    
    
    //第二种做法
    NSDateFormatter *fm  = [[NSDateFormatter alloc]init];
    fm.dateFormat = @"yyyy-MM-dd";
    
    NSString *nowDate = [fm stringFromDate:[NSDate date]];
    NSString *selfDate = [fm stringFromDate:self];
    
    return [nowDate isEqualToString:selfDate];
    
}

//是否是昨天
- (BOOL)isYesterday{
    
    
    NSDateFormatter *fm = [[NSDateFormatter alloc]init];
    fm.dateFormat = @"yyyy-MM-dd";
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    //将时间转换成只有年月日的格式
    NSDate *nowDate = [fm dateFromString:[fm stringFromDate:[NSDate date]]];
    NSDate *selfDate = [fm dateFromString:[fm stringFromDate:self]];
    
    NSDateComponents *components =[calendar components:NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear fromDate:selfDate toDate:nowDate options:0];
    
    return components.year == 0
    &&components.month == 0
    &&components.day == 1;
    
}


@end
