//
//  NSDate+WTExtension.h
//  百思不得姐
//
//  Created by GRIM on 16/5/22.
//  Copyright © 2016年 董文涛. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (WTExtension)

//计算时间差
- (NSDateComponents *)deltaFrom:(NSDate *)from;

//是否是今天
- (BOOL)isToday;
//是否是昨天
- (BOOL)isYesterday;
//是否是今年
- (BOOL)isThisYear;

@end
