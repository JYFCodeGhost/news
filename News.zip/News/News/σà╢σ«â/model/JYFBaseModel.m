//
//  JYFBaseModel.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFBaseModel.h"
#import "NSDate+WTExtension.h"
@implementation JYFBaseModel
-(CGFloat )textH {
    if (!_textH) {
        CGSize titleSize = CGSizeMake(YFMAIN_SCREEN_WIDTH-20, MAXFLOAT);
        _textH = [self.Title boundingRectWithSize:titleSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
    }
    return _textH;
}

-(NSString *)showTimeStr {
    NSTimeInterval timeInterval = self.ShowTime;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];
   
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat=@"yyyy-MM-dd HH:mm:ss";
 
 if (date.isThisYear) {
        if (date.isToday) {
            NSDateComponents *components=[[NSDate date] deltaFrom:date];
            if (components.hour>1) {
                return [NSString stringWithFormat:@"%zd小时前",components.hour];
            } else if (components.minute>1) {
            
                return [NSString stringWithFormat:@"%zd分钟前",components.minute];
            } else {
                return [NSString stringWithFormat:@"刚刚"];
            }
        } else if (date.isYesterday)//昨天
        {
        formatter.dateFormat=@"昨天HH:mm:ss";
            return [formatter stringFromDate:date];
        } else {
        formatter.dateFormat=@"MM-dd HH:mm:ss";//非昨天
            return [formatter stringFromDate:date];
        }
    } else {//不是今年
    return  [NSString stringWithFormat:@"%@",date];
    }

}
@end
