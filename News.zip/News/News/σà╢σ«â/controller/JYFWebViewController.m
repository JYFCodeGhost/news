//
//  JYFWebViewController.m
//  News
//
//  Created by 千锋 on 16/6/6.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFWebViewController.h"

@interface JYFWebViewController ()
/**webView*/
@property(nonatomic, strong)UIWebView *webView;
@end

@implementation JYFWebViewController
//懒加载
-(UIWebView *)webView {
    if (!_webView) {
        _webView=[[UIWebView alloc] initWithFrame:self.view.bounds];
        _webView.dataDetectorTypes=UIDataDetectorTypeAll;
    }
    return _webView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadWebView];
}

-(void)loadWebView {
    [self.view addSubview:self.webView];
//让浏览器加载指定字符串，使用百度搜索
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.WebViewUrl]];
    [self.webView sizeToFit];
    [self.webView loadRequest:request];
    
  //  [self.webView loadHTMLString:self.WebViewUrl baseURL:nil];
    
}

@end
