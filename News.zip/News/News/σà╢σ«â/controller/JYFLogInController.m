//
//  JYFLogInController.m
//  News
//
//  Created by 千锋 on 16/6/7.
//  Copyright © 2016年 金勇帆. All rights reserved.
//
/**
 *  运行时runtime
 *
 *  
 */
#import "JYFLogInController.h"

@interface JYFLogInController ()
@property (weak, nonatomic) IBOutlet UIButton *registerButton;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *logInSpaceToTopViewleft;


@end

@implementation JYFLogInController
- (IBAction)dismissAction:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)showRegister:(UIButton *)sender {
        if (self.logInSpaceToTopViewleft.constant==0) {
        [sender setTitle:@"已有账号?" forState:UIControlStateNormal];
         _logInSpaceToTopViewleft.constant=-self.view.YF_width;
      
        } else {
        [sender setTitle:@"快速注册" forState:UIControlStateNormal];
            self.logInSpaceToTopViewleft.constant=0;
            
        }
   
    [UIView animateWithDuration:0.2 animations:^{
        [self.view layoutIfNeeded];
    }];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
}
//-(void)setUpPhoneTextFilePlaceHolderColor {
//    NSMutableDictionary *attributes=[NSMutableDictionary dictionary];
//    attributes[NSForegroundColorAttributeName]=[UIColor grayColor];
//    NSAttributedString *attrPlaceHolder= [[NSAttributedString alloc] initWithString:@"手机号" attributes:attributes];
//    self.phoneTextFile.attributedPlaceholder=attrPlaceHolder;
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
