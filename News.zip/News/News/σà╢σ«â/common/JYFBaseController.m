//
//  JYFBaseController.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFBaseController.h"

@interface JYFBaseController ()

@end

@implementation JYFBaseController
//懒加载
-(AFHTTPSessionManager *)manager {
    if (!_manager) {
        _manager=[AFHTTPSessionManager manager];
        //设置json数据序列化
        _manager.responseSerializer=[AFJSONResponseSerializer serializer];
        //在序列化器中追加一个类型，text/html这个类型是不支持的
        _manager.responseSerializer.acceptableContentTypes=[_manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    }
    return _manager;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=YFMAIN_COLOR;
    
    
    
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
