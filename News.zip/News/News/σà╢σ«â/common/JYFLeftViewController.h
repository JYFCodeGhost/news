//
//  JYFLeftViewController.h
//  News
//
//  Created by 千锋 on 16/6/10.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYFLeftViewController : UIViewController

@end
