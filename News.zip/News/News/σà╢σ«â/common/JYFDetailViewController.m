//
//  JYFDetailViewController.m
//  News
//
//  Created by 千锋 on 16/6/6.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFDetailViewController.h"

@interface JYFDetailViewController ()
/**webView*/
@property(nonatomic, strong)UIWebView *webView;

@end

@implementation JYFDetailViewController


//懒加载
-(UIWebView *)webView {
    if (!_webView) {
        _webView=[[UIWebView alloc] initWithFrame:self.view.bounds] ;
        _webView.dataDetectorTypes=UIDataDetectorTypeAll;
    }
    return _webView;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self.view addSubview:self.webView];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.webViewStr]];
    [self.webView sizeToFit];
    [self.webView loadRequest:request];
    
    
    
   
    self.webView.contentMode = UIViewContentModeScaleToFill;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    

}

-(void)viewDidAppear:(BOOL)animated {

    [super viewDidAppear:animated];
    YFlog(@"%@",self.webViewStr);
    [self.webView loadHTMLString:self.webViewStr baseURL:[NSURL URLWithString:@"https://www.baidu.com"]];
    _webView.scalesPageToFit = YES;

    self.navigationItem.title=@"阅读";

}

@end
