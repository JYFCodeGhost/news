//
//  JYFNavigationController.h
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYFNavigationController : UINavigationController

@end
