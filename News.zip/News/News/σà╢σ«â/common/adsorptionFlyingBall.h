//
//  adsorptionFlyingBall.h
//  吸附小球
//
//  Created by 千锋 on 16/5/21.
//  Copyright (c) 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^block)();
@interface adsorptionFlyingBall : UIView
@property(nonatomic, copy) NSString *iconImage;//
@property(nonatomic, assign) CGPoint startPoint;
@property(nonatomic ,assign) CGPoint endPoint;
@property(nonatomic, copy) block block;
@end
