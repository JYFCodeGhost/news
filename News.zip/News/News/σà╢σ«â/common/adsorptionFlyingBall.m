//
//  adsorptionFlyingBall.m
//  吸附小球
//
//  Created by 千锋 on 16/5/21.
//  Copyright (c) 2016年 金勇帆. All rights reserved.
//

#import "adsorptionFlyingBall.h"
#import "JYFLogInController.h"
#define FLYINGBALL_WIDTH 60
#define MAINCOLOR [UIColor colorWithRed:225/225.0f green:18/255.0f blue:69/255.0f alpha:1]
@interface adsorptionFlyingBall()<UIDynamicAnimatorDelegate>
//背景视图
@property(nonatomic, strong) UIView *backgroudView;
//图片视图
@property(nonatomic, strong)UIImageView *imageView;
@property(nonatomic, strong) UIDynamicAnimator *animator;//物理仿真动画
@end
@implementation adsorptionFlyingBall

//初始化
-(instancetype)initWithFrame:(CGRect)frame {
    frame.size.width = FLYINGBALL_WIDTH;
    frame.size.height = FLYINGBALL_WIDTH;
    if (self=[super initWithFrame:frame]) {
        
        [self createUI];
        [self breatheAnimationOflight];
    }
    return self;
}

-(void)createUI{
    _backgroudView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, FLYINGBALL_WIDTH, FLYINGBALL_WIDTH)];
    _backgroudView.layer.cornerRadius=FLYINGBALL_WIDTH/2.0f;
    _backgroudView.clipsToBounds = YES;
    _backgroudView.backgroundColor = [MAINCOLOR colorWithAlphaComponent:0.6f];
    _backgroudView.userInteractionEnabled=NO;
    [self addSubview:_backgroudView];
    
    //图片背景视图
    
    UIView *imageBackgroundview = [[UIView alloc] initWithFrame:CGRectMake(5, 5, FLYINGBALL_WIDTH-10, FLYINGBALL_WIDTH-10)];
    imageBackgroundview.layer.cornerRadius=imageBackgroundview.frame.size.width/2.0f;
    imageBackgroundview.backgroundColor=[MAINCOLOR colorWithAlphaComponent:0.8f];
    imageBackgroundview.userInteractionEnabled=NO;
    [self addSubview:imageBackgroundview];
    
    _imageView = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:_iconImage] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate]];
    _imageView.tintColor= [UIColor whiteColor];
    _imageView.frame = CGRectMake(0, 0, 30, 30);
    _imageView.center = CGPointMake(FLYINGBALL_WIDTH/2.0f, FLYINGBALL_WIDTH/2.0f);
    [self addSubview:_imageView];
    [self insertSubview:_imageView atIndex:0];
    self.layer.cornerRadius = FLYINGBALL_WIDTH/2.0f;
    
}
#pragma mark - 呼吸动画
-(void) breatheAnimationOflight {
    __weak typeof (self) weakSelf = self;
[UIView animateWithDuration:2.0f animations:^{
    weakSelf.backgroudView.backgroundColor=[weakSelf.backgroudView.backgroundColor colorWithAlphaComponent:0.1f];
} completion:^(BOOL finished) {
    [weakSelf breatheAnimationOfDark];
}];

}
-(void)breatheAnimationOfDark {
    __weak typeof (self) weakSelf = self;
    [UIView animateWithDuration:2.0f animations:^{
        weakSelf.backgroudView.backgroundColor=[weakSelf.backgroudView.backgroundColor colorWithAlphaComponent:0.7f];
    } completion:^(BOOL finished) {
        [weakSelf breatheAnimationOflight];
    }];

}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    //得到初始触摸坐标点
    UITouch *startTouch = [touches anyObject];
    self.startPoint = [startTouch locationInView:self.superview];
    [self.animator removeAllBehaviors];
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *moveTouch  = [touches anyObject];
    self.center = [moveTouch locationInView:self.superview];
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {

    UITouch *endTouch = [touches anyObject];
    self.endPoint = [endTouch locationInView:self.superview];
    
//判断视图小球该吸附于何处

    [self locationOfFlyingball];
}
#pragma mark - 判断视图小球该吸附于何处
-(void)locationOfFlyingball{
    CGFloat range = 5;
    CGFloat offsetX = self.endPoint.x-self.startPoint.x;
    CGFloat offsetY = self.endPoint.y-self.startPoint.y;
    CGFloat offset = sqrtf((offsetX*offsetX+offsetY*offsetY)
                           );
    if (offset<range) {
        //未移动， 可执行点击图片的相关事宜
        //JYFLogInController *login = [[JYFLogInController alloc] init];
        
        
    } else {
    
        self.center = self.endPoint;
        //计算距离最近的边缘吸附
        CGFloat superViewWidth = self.superview.bounds.size.width;
        CGFloat superViewHeight = self.superview.bounds.size.height;
        //自身的x y坐标
        CGFloat selfX = self.center.x;
        CGFloat selfY = self.center.y;
        
        //计算距离最近的边缘
        CGFloat topDistans = selfY;
        CGFloat bottomDistans = superViewHeight-selfY;
        CGFloat leadingDistans = selfX;
        CGFloat trailingDistans = superViewWidth-selfX;
        CGFloat minRangeX = topDistans<bottomDistans?topDistans:bottomDistans;
        CGFloat minRangDistansY = leadingDistans<trailingDistans?leadingDistans:trailingDistans;
        CGFloat minR = minRangeX<minRangDistansY?minRangeX:minRangDistansY;
         //判断最小距离属于上下左右哪个方向 并设置该方向边缘的point属性
        
        CGFloat offsetMin = 30;
        CGPoint poin;
        if (minR==topDistans) {
            selfX = selfX-offsetMin<0?offsetMin:selfX;
            selfX = selfX+offsetMin>superViewWidth?superViewWidth-offsetMin:selfX;
           poin = CGPointMake(selfX, offsetMin);
        } else if(minR==bottomDistans){
            selfX = selfX-offsetMin<0?offsetMin:selfX;
            selfX = selfX+offsetMin>superViewWidth?superViewWidth-offsetMin:selfX;
           poin = CGPointMake(selfX, superViewHeight-offsetMin);
        
        }else if (minR==leadingDistans) {
            selfY=selfY-offsetMin<0?offsetMin:selfY;
            selfY=selfY+offsetMin>superViewHeight?superViewHeight-offsetMin:selfY;
            poin = CGPointMake(0+offsetMin, selfY);
        }else if (minR==trailingDistans) {
            selfY=selfY-offsetMin<0?offsetMin:selfY;
            selfY=selfY+offsetMin>superViewHeight?superViewHeight-offsetMin:selfY;
            poin = CGPointMake(superViewWidth-offsetMin, selfY);
        }
        
        //添加吸附物理行为
        UIAttachmentBehavior *attachment = [[UIAttachmentBehavior alloc] initWithItem:self attachedToAnchor:poin];
        [attachment setLength:0];
        [attachment setDamping:0.05];
        [attachment setFrequency:10];
        [self.animator addBehavior:attachment];
    }

}

-(UIDynamicAnimator *)animator {
    if (!_animator) {
        _animator=[[UIDynamicAnimator alloc] initWithReferenceView:self.superview];
        _animator.delegate=self;
    }
    return _animator;
}

- (void)dynamicAnimatorWillResume:(UIDynamicAnimator *)animator{
    self.backgroundColor= [UIColor greenColor];

}
-(void)dynamicAnimatorDidPause:(UIDynamicAnimator *)animator {
   

}




@end
