//
//  JYFLeftViewController.m
//  News
//
//  Created by 千锋 on 16/6/10.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFLeftViewController.h"
#import "JYFLogInController.h"
@interface JYFLeftViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *springView;


@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UIButton *logInButton;

- (IBAction)LoginAction:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *collectButton;


@end

@implementation JYFLeftViewController

-(void)awakeFromNib {
    [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([JYFLeftViewController class]) owner:nil options:nil];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.iconImageView.layer.cornerRadius=25;
    self.iconImageView.layer.masksToBounds=YES;
    [self.view insertSubview:self.springView belowSubview:self.iconImageView];
  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)LoginAction:(UIButton *)sender {
        JYFLogInController *loginC= [[JYFLogInController alloc] init];
        [self presentViewController:loginC animated:YES completion:nil];
}
@end
