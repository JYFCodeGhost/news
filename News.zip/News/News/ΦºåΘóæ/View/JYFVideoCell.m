//
//  JYFVideoCell.m
//  News
//
//  Created by 千锋 on 16/6/5.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFVideoCell.h"
#import "JYFVideoModel.h"
@interface JYFVideoCell() 

@end
@implementation JYFVideoCell

- (void)awakeFromNib {
    // Initialization code
    }

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)videoPlayAction:(UIButton *)sender {
    
}
- (IBAction)praiseAction:(UIButton *)sender {
    sender.enabled=NO;
    sender.userInteractionEnabled=NO;
    [sender setTitle:[NSString stringWithFormat:@"%ld",self.videoModel.DingCount+1] forState:UIControlStateDisabled];
    
}
- (IBAction)belittleAction:(UIButton *)sender {
    sender.enabled=NO;
    sender.userInteractionEnabled=NO;
    [sender setTitle:[NSString stringWithFormat:@"%ld",self.videoModel.CaiCount+1] forState:UIControlStateDisabled];

}
- (IBAction)shareAction:(UIButton *)sender {
    
    
    
}

-(void)setVideoModel:(JYFVideoModel *)videoModel {
    _videoModel=videoModel;
    self.titleLabel.text=_videoModel.Title;
    [self.pictureImageView sd_setImageWithURL:[NSURL URLWithString:_videoModel.CoverImgs[0]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
    self.categoryLabel.text=_videoModel.FromName;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat=@"HH:mm:ss";
    NSDate *date = [formatter dateFromString:[NSString stringWithFormat:@"%ld",_videoModel.ShowTime]];
    self.showTimeLabel.text=[formatter stringFromDate:date];
    self.praiseButton.titleLabel.text=[NSString stringWithFormat:@"%ld",_videoModel.DingCount];
    self.belittleButton.titleLabel.text=[NSString stringWithFormat:@"%ld",_videoModel.CaiCount];

    //[self videoPlayer];

}

@end
