//
//  JYFVideoController.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFVideoController.h"
#import "JYFVideoModel.h"
#import "JYFVideoCell.h"
@interface JYFVideoController ()<UITableViewDataSource,UITableViewDelegate>
/**manger网络*/
@property(nonatomic, strong)AFHTTPSessionManager *HttpManager;
/**数据源数组*/
@property(nonatomic, strong)NSMutableArray *VideoDataArray;

/**UiTableView*/
@property(nonatomic, strong)UITableView *videoTableView;

/**channelId*/
@property(nonatomic, assign)NSInteger channelId;
/**type*/
@property(nonatomic, assign)NSInteger type;
/**timestamp*/
@property(nonatomic, copy)NSString* timestamp;
@end
//cell标识符
static NSString * const identifireVideo = @"videoCell";

@implementation JYFVideoController
//懒加载
-(AFHTTPSessionManager *)HttpManager {
    if (!_HttpManager) {
        _HttpManager=[AFHTTPSessionManager manager];
        _HttpManager.responseSerializer=[AFJSONResponseSerializer serializer];
        _HttpManager.responseSerializer.acceptableContentTypes=[_HttpManager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    }
    return _HttpManager;
}
//懒加载
-(NSMutableArray *)VideoDataArray {
    if (!_VideoDataArray) {
        _VideoDataArray=[[NSMutableArray alloc] init];
    }
    return _VideoDataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=YFMAIN_COLOR;
    self.channelId=6;
    self.type=1;
    self.timestamp=@"0";
    [self createView];
}

-(void)createView {
    __weak typeof(self) weakSelf = self;
    
   _videoTableView=[[UITableView alloc] init];
    [self.view addSubview:_videoTableView];
    _videoTableView.delegate=self;
    _videoTableView.dataSource=self;
    [_videoTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakSelf.view);
    }];
    //注册xib
    [self.videoTableView registerNib:[UINib nibWithNibName:NSStringFromClass([JYFVideoCell class]) bundle:nil] forCellReuseIdentifier:identifireVideo];
    //刷新数据
    self.videoTableView.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        weakSelf.videoTableView.mj_footer.hidden=YES;
        [weakSelf requestDataWithchannelId:weakSelf.channelId type:weakSelf.type timestamp:weakSelf.timestamp];
    }];
    self.videoTableView.mj_footer=[MJRefreshAutoFooter footerWithRefreshingBlock:^{
        weakSelf.videoTableView.mj_header.hidden=YES;
        [weakSelf requestDataWithchannelId:weakSelf.channelId type:weakSelf.type timestamp:weakSelf.timestamp];
    }];
    
    [self.videoTableView.mj_header beginRefreshing];
}

//MARK 请求数据
-(void)requestDataWithchannelId:(NSInteger)channelId type:(NSInteger) type  timestamp:(NSString *) timestamp{
    __weak typeof(self) weakSelf = self;
    NSString *url = [NSString stringWithFormat:TOTAL_Url,channelId,type,timestamp];
    [self.HttpManager GET:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSArray *array=[NSArray yy_modelArrayWithClass:[JYFVideoModel class] json:responseObject[@"content_list"]];
        [weakSelf.VideoDataArray addObjectsFromArray:array];
        weakSelf.timestamp =responseObject[@"timestamp"];
        
        YFlog(@"%@",weakSelf.timestamp);
        ;
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.videoTableView.mj_header endRefreshing];
            [weakSelf.videoTableView.mj_footer endRefreshing];
            weakSelf.videoTableView.mj_footer.hidden=NO;
            weakSelf.videoTableView.mj_header.hidden=NO;
            [weakSelf.videoTableView reloadData];
        });
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [KVNProgress showWithStatus:error.localizedDescription onView:weakSelf.view];
    }];
    
}

#pragma mark - 协议方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {


    return self.VideoDataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    JYFVideoCell *cell = [tableView dequeueReusableCellWithIdentifier:identifireVideo forIndexPath:indexPath];
    JYFVideoModel *model = self.VideoDataArray[indexPath.row];
    cell.videoModel=model;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    JYFVideoModel *model = self.VideoDataArray[indexPath.row];
    
    return model.titleH+YFMAIN_SCREEN_WIDTH*281/500.0f+35+22;
}
@end
