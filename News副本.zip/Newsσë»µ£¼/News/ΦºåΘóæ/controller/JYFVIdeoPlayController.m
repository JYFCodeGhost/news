//
//  JYFVIdeoPlayController.m
//  News
//
//  Created by 千锋 on 16/6/6.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFVIdeoPlayController.h"
@interface JYFVIdeoPlayController ()

@end

@implementation JYFVIdeoPlayController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self videoPlayer];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 视频播放
-(void)videoPlayer {
    //1.创建item对象
    AVPlayerItem *item = [[AVPlayerItem alloc] initWithURL:[NSURL URLWithString:_videoUrl]];
    YFlog(@"url=====%@",self.videoUrl);
    ////2.创建播放器对象
    _player=[AVPlayer playerWithPlayerItem:item];
    //播放
    [_player play];
    //================显示图像==================
    //1.创建显示视图的layer（专门用来显示视频的图像）
    //参数:播放器
    _Layer=[AVPlayerLayer playerLayerWithPlayer:_player];
    _Layer.frame=self.view.bounds;
    //3.添加到界面上
    [self.view.layer addSublayer:_Layer];
    
    //4.获取视频界面的大小
    CGRect rect = _Layer.videoRect;
    
    //5.创建一个进度条
    _progress = [[UIProgressView alloc] initWithFrame:CGRectMake(rect.origin.x, rect.origin.y + rect.size.height, rect.size.width,8)];
    [self.view addSubview:_progress];
    
    
    //6.更新进度
    __weak UIProgressView * tprogress = _progress;
    [_player addPeriodicTimeObserverForInterval:CMTimeMake(1, 10) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
        
        //总时间
        float total = _player.currentItem.duration.value * 1.0f / _player.currentItem.duration.timescale;
        
        //当前时间
        float current = time.value * 1.0f / time.timescale;
        
        tprogress.progress = current / total;
        
        
    }];
    
    //7.显示样式
    //AVLayerVideoGravityResizeAspect //默认的，视频有多大就显示多大，视频没有缩放（竖屏）
    //AVLayerVideoGravityResize //layer有多大，视频就显示多大,视频会有缩放（竖屏）
    //AVLayerVideoGravityResizeAspectFill  //layer有多大，视频就显示多大，视频显示不全（竖屏）
    [_Layer setVideoGravity:AVLayerVideoGravityResizeAspect];
    
    
        //==============屏幕旋转====================
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(screenChangeSate) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
    
    
    
    
    
    
}
#pragma mark - 消息中心
- (void)screenChangeSate{
    
    _Layer.frame = self.view.bounds;
    
    CGRect rect = _Layer.videoRect;
    _progress.frame = CGRectMake(rect.origin.x, rect.origin.y + rect.size.height - 8, rect.size.width,8);
    
}


@end
