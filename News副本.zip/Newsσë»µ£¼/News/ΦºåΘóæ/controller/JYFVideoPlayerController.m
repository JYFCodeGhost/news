//
//  JYFVideoPlayerController.m
//  News
//
//  Created by 千锋 on 16/6/6.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFVideoPlayerController.h"
#import <MediaPlayer/MediaPlayer.h>
@interface JYFVideoPlayerController ()
/**movie*/
@property(nonatomic, strong)MPMoviePlayerController *moviePlayerC;
@end
@implementation JYFVideoPlayerController
//懒加载
-(MPMoviePlayerController *)moviePlayerC {
    if (!_moviePlayerC) {
        _moviePlayerC=[[MPMoviePlayerController alloc] initWithContentURL:[NSURL URLWithString:self.movieUrl]];
    }
    return _moviePlayerC;
}
-(void)setupMoviePlay {
//2.设置frame
self.moviePlayerC.view.frame = self.view.bounds;
//3.显示在界面上
[self.view addSubview:self.moviePlayerC.view];
//4.开始播放
[self.moviePlayerC play];

//    //5.暂停播放
//    [self.mpMovieController stop];

//6.设置显示样式
//    MPMovieControlStyleNone,  没有控制条
//    MPMovieControlStyleEmbedded,  有控制条，视频居中显示
//    MPMovieControlStyleFullscreen  只有全屏
[self.moviePlayerC setControlStyle:MPMovieControlStyleEmbedded];

//7.检测视频播放结束
[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(endPlay) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];



}

#pragma mark - 消息中心
- (void)endPlay{
//    self.moviePlayerC.contentURL = [NSURL URLWithString:path];
//    [self.moviePlayerC play];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor clearColor];
    
    [self setupMoviePlay];
    [self backButton];
}
-(void)backButton{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:[[UIImage imageNamed:@"tebu"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
   
    button.frame=CGRectMake(0, self.navigationController.navigationBar.YF_Y, 274/3.0f, 135/3.0f);
    [self.view addSubview:button];
  
    
    [button addTarget:self action:@selector(goBackNewsList:) forControlEvents:UIControlEventTouchUpInside];
}
-(void)goBackNewsList:(UIButton *)sender{

[self dismissViewControllerAnimated:YES completion:^{
    [self.moviePlayerC stop];
}];

}
-(void)dealloc {
   
}

@end
