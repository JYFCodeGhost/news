//
//  JYFVIdeoPlayController.h
//  News
//
//  Created by 千锋 on 16/6/6.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface JYFVIdeoPlayController : UIViewController{
    //播放器
    //显示画面的layer
    UIProgressView *_progress;
    
}
/**player*/
@property(nonatomic, strong)AVPlayer *player;
@property(nonatomic, strong) AVPlayerLayer *Layer;
/**视频地址*/
@property(nonatomic, copy)NSString *videoUrl;
-(void)videoPlayer;

@end
