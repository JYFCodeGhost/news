//
//  JYFVideoModel.m
//  News
//
//  Created by 千锋 on 16/6/5.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFVideoModel.h"

@implementation JYFVideoModel

-(CGFloat)titleH {
    if (!_titleH) {
        CGSize textSize = CGSizeMake(YFMAIN_SCREEN_WIDTH-20, MAXFLOAT);
        _titleH=[self.Title boundingRectWithSize:textSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
    }
    return _titleH;
}

@end
