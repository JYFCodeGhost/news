//
//  JYFVideoCell.h
//  News
//
//  Created by 千锋 on 16/6/5.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@class JYFVideoModel;
@interface JYFVideoCell : UITableViewCell 
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UIImageView *pictureImageView;
@property (weak, nonatomic) IBOutlet UIButton *videoPlayButton;
- (IBAction)videoPlayAction:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UILabel *categoryLabel;
@property (weak, nonatomic) IBOutlet UILabel *showTimeLabel;
@property (weak, nonatomic) IBOutlet UIButton *praiseButton;

- (IBAction)praiseAction:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *belittleButton;
- (IBAction)belittleAction:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *collectButton;
@property (weak, nonatomic) IBOutlet UIButton *shareButton;
- (IBAction)shareAction:(UIButton *)sender;
//数据模型
@property(nonatomic, strong) JYFVideoModel *videoModel;


@end
