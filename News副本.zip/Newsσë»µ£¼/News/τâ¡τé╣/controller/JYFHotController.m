//
//  JYFHotController.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFHotController.h"

@interface JYFHotController ()

@end

@implementation JYFHotController

- (void)viewDidLoad {
    [super viewDidLoad];
    //参数初始化
    self.channelId=2;
    self.type=1;
    self.timestamp =@"0";
    self.title=@"时事热点";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
