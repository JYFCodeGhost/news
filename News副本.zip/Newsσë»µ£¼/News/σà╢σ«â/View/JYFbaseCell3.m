//
//  JYFbaseCell3.m
//  News
//
//  Created by 千锋 on 16/6/4.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFbaseCell3.h"
#import "JYFBaseModel.h"
@implementation JYFbaseCell3

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(JYFBaseModel *)model {
    _model=model;
    self.timeLabel.text=[NSString stringWithFormat:@"%ld",_model.ShowTime];
    self.titleLabel.text=_model.Title;
    self.commentLabel.text=[NSString stringWithFormat:@"%ld",_model.CommentCount];
    self.categoryLabel.text=_model.FromName;

}
@end
