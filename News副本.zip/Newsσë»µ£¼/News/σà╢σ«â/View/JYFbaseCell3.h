//
//  JYFbaseCell3.h
//  News
//
//  Created by 千锋 on 16/6/4.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYFBaseModel;
@interface JYFbaseCell3 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *categoryLabel;

@property (weak, nonatomic) IBOutlet UILabel *commentLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (weak, nonatomic) IBOutlet UIImageView *XimageView;
@property(nonatomic,strong) JYFBaseModel *model;
@end
