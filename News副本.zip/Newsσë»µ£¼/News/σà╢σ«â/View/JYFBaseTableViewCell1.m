//
//  JYFBaseTableViewCell1.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFBaseTableViewCell1.h"
#import "JYFBaseModel.h"
@implementation JYFBaseTableViewCell1

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setModel:(JYFBaseModel *)model {
    if (model.CoverImgs.count==1) {
        _model=model;
        [self.picture1ImageV sd_setImageWithURL:[NSURL URLWithString:_model.CoverImgs[0]] placeholderImage:[UIImage imageNamed:@"1.jpg"]];
        self.title1Label.text=_model.Title;
        self.category1Label.text=_model.FromName;
        
        self.comment1Label.text=[NSString stringWithFormat:@"%ld",_model.CommentCount];
        self.time1Label.text=[NSString stringWithFormat:@"%ld", _model.ShowTime];
    }
    
    
}
@end
