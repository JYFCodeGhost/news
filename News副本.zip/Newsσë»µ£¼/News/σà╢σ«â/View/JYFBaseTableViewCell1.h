//
//  JYFBaseTableViewCell1.h
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYFBaseModel;
@interface JYFBaseTableViewCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *title1Label;
@property (weak, nonatomic) IBOutlet UILabel *category1Label;
@property (weak, nonatomic) IBOutlet UILabel *comment1Label;

@property (weak, nonatomic) IBOutlet UIImageView *picture1ImageV;
@property (weak, nonatomic) IBOutlet UILabel *time1Label;
@property (weak, nonatomic) IBOutlet UIImageView *x1ImageV;

@property(nonatomic,strong) JYFBaseModel *model;

@end
