//
//  JYFTextField.m
//  News
//
//  Created by 千锋 on 16/6/7.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFTextField.h"
#import <objc/runtime.h>
static NSString * const textFieldPlaceholderPath = @"_placeholderLabel.textColor";
@implementation JYFTextField

-(void)awakeFromNib {
 //   [self resignFirstResponder];
    //设置光标颜色
    self.tintColor=self.textColor;

}
//查找textfield的隐藏属性（所有属性）
//+(void)initialize {
//    unsigned int count = 0;
//    Ivar *ivar = class_copyIvarList([UITextField class], &count);
//    for (int i = 0; i<count; i++) {
//        Ivar iva = *(ivar+i);
//        //打印成员变量名字
//        YFlog(@"%s",ivar_getName(iva));
//    }
//    free(ivar);
//}

//-(BOOL)becomeFirstResponder {
//    [self setValue:[UIColor whiteColor] forKey:textFieldPlaceholderPath];
//    
//    return [super becomeFirstResponder];
//}
//-(BOOL)resignFirstResponder {
//
//    [self setValue:[UIColor grayColor] forKey:textFieldPlaceholderPath];
//    return [super resignFirstResponder];
//}
@end
