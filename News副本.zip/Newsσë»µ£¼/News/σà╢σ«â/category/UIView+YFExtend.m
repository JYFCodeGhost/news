//
//  UIView+YFExtend.m
//  ECook
//
//  Created by 千锋 on 16/5/30.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "UIView+YFExtend.h"

@implementation UIView (YFExtend)
-(CGFloat)YF_width {
    return self.frame.size.width;
}
-(CGFloat)YF_height {
    return self.frame.size.height;
}
-(CGSize)YF_size{
    return self.frame.size;
}
-(CGFloat)YF_X {
    return self.frame.origin.x;
}
-(CGFloat)YF_Y {
    return self.frame.origin.y;
}
-(void)setYF_width:(CGFloat)YF_width {
    CGRect YFframe = self.frame;
    YFframe.size.width=YF_width;
    self.frame=YFframe;
}
-(void)setYF_height:(CGFloat)YF_height {
    CGRect YFframe = self.frame;
    YFframe.size.height=YF_height;
    self.frame=YFframe;
}
-(void)setYF_size:(CGSize)YF_size {
    CGRect YFframe = self.frame;
    YFframe.size=YF_size;
    self.frame=YFframe;
}
-(void)setYF_X:(CGFloat)YF_X {
    CGRect YFframe = self.frame;
    YFframe.origin.x=YF_X;
    self.frame=YFframe;
}
-(void)setYF_Y:(CGFloat)YF_Y {
    CGRect YFframe = self.frame;
    YFframe.origin.y=YF_Y;
    self.frame=YFframe;
}
@end
