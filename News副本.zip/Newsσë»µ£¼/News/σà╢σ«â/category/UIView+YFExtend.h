//
//  UIView+YFExtend.h
//  ECook
//
//  Created by 千锋 on 16/5/30.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (YFExtend)
@property(nonatomic, assign) CGFloat YF_width;
@property(nonatomic,assign) CGFloat YF_height;
@property(nonatomic, assign)CGFloat YF_X;
@property(nonatomic,assign)CGFloat YF_Y;
@property(nonatomic, assign)CGSize YF_size;
@end
