//
//  Header.h
//  ECook
//
//  Created by 千锋 on 16/5/30.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#ifndef Header_h
#define Header_h


//总的
#define TOTAL_Url @"http://v1.api.danchequ.com/ttapi/List/?token=4c8c7a0a-4079-43ad-b575-6e406186712f&channelId=%ld&type=%ld&timestamp=%@&market=qq&v=1.5.7"

//###国际get
#define INTERNATIONAL_Url @"http://v1.api.danchequ.com/ttapi/List/?token=4c8c7a0a-4079-43ad-b575-6e406186712f&channelId=4&type=1&timestamp=1464938391&market=qq&v=1.5.7"

// http://v1.api.danchequ.com/ttapi/List/?token=4c8c7a0a-4079-43ad-b575-6e406186712f&channelId=4&type=2&timestamp=1464930587&market=qq&v=1.5.7
//###detail
#define INTERNATIONAL_Detail_Url @"http://v1.api.danchequ.com/ttapi/Detailed?id=1195071&token=4c8c7a0a-4079-43ad-b575-6e406186712f&market=qq&v=1.5.7"

//###视频
#define VEDIO_Url @"http://v1.api.danchequ.com/ttapi/List/?token=4c8c7a0a-4079-43ad-b575-6e406186712f&channelId=6&type=1&timestamp=0&market=qq&v=1.5.7"

//###历史
#define HISTORY_Url @"http://v1.api.danchequ.com/ttapi/List/?token=4c8c7a0a-4079-43ad-b575-6e406186712f&channelId=5&type=1&timestamp=0&market=qq&v=1.5.7"
//###detail
#define HISTORY_Detail_Url @"http://v1.api.danchequ.com/ttapi/Detailed?id=1194916&token=4c8c7a0a-4079-43ad-b575-6e406186712f&market=qq&v=1.5.7"

//###热点
#define HOT_Url @"http://v1.api.danchequ.com/ttapi/List/?token=4c8c7a0a-4079-43ad-b575-6e406186712f&channelId=2&type=1&timestamp=0&market=qq&v=1.5.7"

//###detail
#define HOT_Detail_Url @"http://v1.api.danchequ.com/ttapi/Detailed?id=1194102&token=4c8c7a0a-4079-43ad-b575-6e406186712f&market=qq&v=1.5.7"


#endif /* Header_h */
