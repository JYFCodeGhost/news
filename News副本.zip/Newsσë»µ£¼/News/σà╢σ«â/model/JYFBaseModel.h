//
//  JYFBaseModel.h
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JYFBaseModel : NSObject<YYModel>

@property (nonatomic, copy) NSString *PublisherName;

@property (nonatomic, assign) NSInteger ShowTime;

@property (nonatomic, copy) NSString *Title;

@property (nonatomic, strong) NSArray *VideoSrcList;

@property (nonatomic, assign) NSInteger FromId;

@property (nonatomic, copy) NSString *FromName;

@property (nonatomic, assign) NSInteger ViewType;

@property (nonatomic, copy) NSString *Intro;

@property (nonatomic, strong) NSArray<NSString *> *CoverImgs;

@property (nonatomic, assign) NSInteger VideoDuration;

@property (nonatomic, assign) NSInteger ContentType;

@property (nonatomic, assign) NSInteger DingCount;

@property (nonatomic, assign) NSInteger CommentCount;

@property (nonatomic, assign) NSInteger CaiCount;

@property (nonatomic, assign) NSInteger ImgShowType;

@property (nonatomic, copy) NSString *PublisherIcon;

@property (nonatomic, assign) NSInteger Id;

@property (nonatomic, assign) NSInteger PublisherId;

@property (nonatomic, assign) NSInteger Mark;

@property (nonatomic, assign) NSInteger SourceType;

@property (nonatomic, copy) NSString *OriginalUrl;
/**cellH*/
@property(nonatomic, assign)CGFloat textH;//Cell的高度
@end
