//
//  JYFBaseModel.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFBaseModel.h"

@implementation JYFBaseModel
-(CGFloat )textH {
    if (!_textH) {
        CGSize titleSize = CGSizeMake(YFMAIN_SCREEN_WIDTH-20, MAXFLOAT);
        _textH = [self.Title boundingRectWithSize:titleSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
    }
    return _textH;
}

@end
