//
//  JYFBaseController.h
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JYFBaseModel.h"
@interface JYFBaseController : UIViewController

/**afhttp*/
@property(nonatomic, strong)AFHTTPSessionManager *manager;

//channelId=%ld&type=%ld&timestamp=%@
/**channelId*/
@property(nonatomic, assign)NSInteger channelId;
/**type*/
@property(nonatomic, assign)NSInteger type;
/**timestamp*/
@property(nonatomic, copy)NSString* timestamp;
@end
