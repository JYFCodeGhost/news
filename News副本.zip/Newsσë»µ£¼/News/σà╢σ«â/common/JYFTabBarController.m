//
//  JYFTabBarController.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFTabBarController.h"
#import "JYFNavigationController.h"
#import "JYFInternationViewController.h"
#import "JYFHistoryController.h"
#import "JYFHotController.h"
#import "JYFVideoController.h"
#import "JYFLogInController.h"
@interface JYFTabBarController ()

@end

@implementation JYFTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createViewWith:[[JYFInternationViewController alloc] init] title:@"国际" iamge:@"nav_coin_icon" selecteIamge:@"nav_coin_icon_click"];
    [self createViewWith:[[JYFHotController alloc] init] title:@"热点" iamge:@"MainTagSubIcon" selecteIamge:@"MainTagSubIconClick"];
    [self createViewWith:[[JYFHistoryController alloc] init] title:@"历史" iamge:@"tiaoman_u" selecteIamge:@"tiaoman_d"];
    [self createViewWith:[[JYFVideoController alloc] init] title:@"视频" iamge:@"faxian_u" selecteIamge:@"faxian_d"];

}

-(void)createViewWith:(UIViewController *)viewController title:(NSString *)title iamge:(NSString *)image selecteIamge:(NSString *) selecteImage{
    JYFNavigationController *navigation = [[JYFNavigationController alloc] initWithRootViewController:viewController];
    navigation.tabBarItem.title=title;
    
    viewController.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"friendsRecommentIcon"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain target:self action:@selector(onClick:)];
    self.tabBar.tintColor=YFCOLOR_rgb(252, 62, 29);
    self.tabBar.backgroundImage=[UIImage imageNamed:@"tabbar-light"];
    [navigation.tabBarItem setImage:[[UIImage imageNamed:image]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [navigation.tabBarItem setSelectedImage:[[UIImage imageNamed:selecteImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [self addChildViewController:navigation];
}

-(void)onClick:(UIBarButtonItem *)sender {
    YFlog(@"侧边点击%s",__func__);
    JYFLogInController *loginC= [[JYFLogInController alloc] init];
    [self presentViewController:loginC animated:YES completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
