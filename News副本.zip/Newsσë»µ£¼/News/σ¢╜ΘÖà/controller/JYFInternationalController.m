//
//  JYFInternationalController.m
//  News
//
//  Created by 千锋 on 16/6/3.
//  Copyright © 2016年 金勇帆. All rights reserved.
//

#import "JYFInternationalController.h"
#import "JYFBaseTableViewCell1.h"
#import "JYFbaseTableViewCell3.h"
#import "JYFbaseCell3.h"
#import "JYFDetailViewController.h"
@interface JYFInternationalController ()<UITableViewDataSource,UITableViewDelegate>
/**tableView*/
@property(nonatomic, strong)UITableView *tableView;
/**数据源数组*/
@property(nonatomic, strong)NSMutableArray *dataArrayy;
/**detailstring*/

@property(nonatomic, copy)NSString *detailStr;
/**<#注释#>*/
@property(nonatomic, strong)JYFDetailViewController *detailCv;

@end
static NSString * const indentifire1 = @"pictureTrailing";
static NSString * const indentifire3 = @"celll";
static NSString * const identifireNo= @"noPicture";
@implementation JYFInternationalController {
    NSInteger _Idd;
}

//懒加载
-(NSMutableArray *)dataArrayy {
    if (!_dataArrayy) {
        _dataArrayy=[[NSMutableArray alloc] init];
    }
    return _dataArrayy;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createView];
    [self.tableView.mj_header beginRefreshing];
}
-(void)createView {
    __weak typeof(self) weakSelf = self;

        
    
////遵循协议
    self.tableView=[[UITableView alloc] init];
    [self.view addSubview:self.tableView];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
   [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
       make.edges.equalTo(weakSelf.view);
   }];
    
    //self.tableView.rowHeight=150;
    
    //注册xib
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([JYFbaseTableViewCell3 class]) bundle:nil] forCellReuseIdentifier:indentifire3];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([JYFBaseTableViewCell1 class]) bundle:nil] forCellReuseIdentifier:indentifire1];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([JYFbaseCell3 class]) bundle:nil] forCellReuseIdentifier:identifireNo];
    
    
    //刷新数据
       self.tableView.mj_header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
           weakSelf.timestamp=[NSString stringWithFormat:@"0"];
        weakSelf.tableView.mj_footer.hidden=YES;
           YFlog(@"%@",weakSelf.timestamp);
        [weakSelf requestDataWithchannelId:weakSelf.channelId type:weakSelf.type timestamp:weakSelf.timestamp];
    }];
    self.tableView.mj_footer=[MJRefreshAutoFooter footerWithRefreshingBlock:^{
        weakSelf.tableView.mj_header.hidden=YES;
        [weakSelf requestDataWithchannelId:weakSelf.channelId type:weakSelf.type timestamp:weakSelf.timestamp];
    }];
    
    [self.tableView.mj_header beginRefreshing];
}

//MARK 请求数据
-(void)requestDataWithchannelId:(NSInteger)channelId type:(NSInteger) type  timestamp:(NSString *) timestamp{
    __weak typeof(self) weakSelf = self;
    NSString *url = [NSString stringWithFormat:TOTAL_Url,channelId,type,timestamp];
    [self.manager GET:url parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
            NSArray *array=[NSArray yy_modelArrayWithClass:[JYFBaseModel class] json:responseObject[@"content_list"]];
        [weakSelf.dataArrayy addObjectsFromArray:array];
        weakSelf.timestamp =responseObject[@"timestamp"];
        
        YFlog(@"%@",weakSelf.timestamp);
        ;

       
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.tableView.mj_header endRefreshing];
            [weakSelf.tableView.mj_footer endRefreshing];
            weakSelf.tableView.mj_footer.hidden=NO;
            weakSelf.tableView.mj_header.hidden=NO;
            [weakSelf.tableView reloadData];
        });
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [KVNProgress showWithStatus:error.localizedDescription onView:weakSelf.view.superview];
    }];
    
}

#pragma mark - 协议方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArrayy.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    JYFBaseModel *modle1 = self.dataArrayy[indexPath.row];
    
    if (modle1.CoverImgs.count==1) {
        
        JYFBaseTableViewCell1 *cell1 = [tableView dequeueReusableCellWithIdentifier:indentifire1 forIndexPath:indexPath];
        
        cell1.model=modle1;
        return cell1;
    } if (modle1.CoverImgs.count==3) {
        
        JYFbaseTableViewCell3 *base3 = [tableView dequeueReusableCellWithIdentifier:indentifire3 forIndexPath:indexPath];
        
        base3.model3=modle1;
        return base3;

    }
    JYFbaseCell3 *cell3 = [tableView dequeueReusableCellWithIdentifier:identifireNo forIndexPath:indexPath];
    cell3.model=modle1;
    return cell3;
    
    }


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    JYFBaseModel *modle1 = self.dataArrayy[indexPath.row];
    if (modle1.CoverImgs.count==1) {
        return 115;
    } else {
        if (modle1.CoverImgs.count==3) {
            return modle1.textH+YFMAIN_SCREEN_WIDTH/3.0f*2/3.0+50;
        } else {
        
        
            return modle1.textH+70;
        }
        
        
    }
    
    

    return 0;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    JYFBaseModel *model = self.dataArrayy[indexPath.row];
      _detailCv = [[JYFDetailViewController alloc] init];
    [self detailRequestWith:model.Id];
    
    
    [self presentViewController:_detailCv animated:YES completion:nil];

}
-( void)detailRequestWith:(NSInteger) Id {
    NSString *Detailurl = [NSString stringWithFormat:Detail_Url,Id];
    
    [self.manager GET:Detailurl parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
      _detailStr =  responseObject[@"article_info"][@"OriginalContent"];
        _detailCv.webViewStr=[NSString stringWithFormat:@"%@",_detailStr];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [KVNProgress showErrorWithStatus:error.localizedDescription onView:self.view completion:^{
            
        }];
    }];
    
}

@end
